package strona.demo.config;

import lombok.Getter;

@Getter
public class RegisterCredentials {
    private String username;
    private String password;
}
