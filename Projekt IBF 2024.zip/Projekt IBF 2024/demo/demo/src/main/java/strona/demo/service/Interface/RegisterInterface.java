package strona.demo.service.Interface;

public interface RegisterInterface {
    void register(String username, String password);
}
