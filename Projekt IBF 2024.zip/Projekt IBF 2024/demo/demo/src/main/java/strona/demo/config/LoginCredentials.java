package strona.demo.config;

import lombok.Getter;

@Getter
public class LoginCredentials {

    private String username;
    private String password;
}
