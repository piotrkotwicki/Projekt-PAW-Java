<script setup lang="ts">
import Footer from '@/components/Footer.vue';
import Header from '@/components/Header.vue';
import Admin from '@/components/Admin.vue';
</script>
<template>
  <!-- Wrapper -->
  <div id="wrapper">

<Header>

</Header>

    <!-- Main -->
        <div id="main">
            <Admin></Admin>

        </div>

<Footer>

</Footer>

</div>

</template>



<style>

</style>