<script setup lang="ts">
import Footer from '@/components/Footer.vue';
import Header from '@/components/Header.vue';
import Directors from '@/components/Directors.vue';
</script>
<template>
    <!-- Wrapper -->
    <div id="wrapper">
  
  <Header>
  
  </Header>
  
      <!-- Main -->
          <div id="main">
              <Directors></Directors>
  
          </div>
  
  <Footer>
  
  </Footer>
  
  </div>
  
  </template>
  
 
  
  <style>
  
  </style>