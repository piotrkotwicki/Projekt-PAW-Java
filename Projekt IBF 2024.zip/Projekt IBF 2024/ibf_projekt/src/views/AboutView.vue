<script lang="ts" setup>

</script>

<template>
    <h1 class="text-3xl mb-8">About me</h1>
    <p>This is About me page</p>  
</template>