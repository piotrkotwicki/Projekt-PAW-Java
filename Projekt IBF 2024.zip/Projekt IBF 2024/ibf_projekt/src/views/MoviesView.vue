<script setup lang="ts">
import Footer from '@/components/Footer.vue';
import Header from '@/components/Header.vue';
import Movies from '@/components/Movies.vue';
</script>
<template>
    <!-- Wrapper -->
    <div id="wrapper">
  
  <Header>
  
  </Header>
  
      <!-- Main -->
          <div id="main">
              <Movies></Movies>
  
          </div>
  
  <Footer>
  
  </Footer>
  
  </div>
  
  </template>
  
  
  
  <style>
  
  </style>