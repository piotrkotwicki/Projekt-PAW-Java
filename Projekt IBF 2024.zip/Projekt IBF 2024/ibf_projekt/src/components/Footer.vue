<template>
  		<!-- Footer -->
          <footer id="footer">
						<section>
							<h3>Autor: Piotr Kotwicki</h3>
						</section>
						
						<p class="copyright">&copy; Untitled. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
					</footer>
</template>



<style>

</style>